
import os
os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"
import cv2
import numpy as np
import matplotlib
import matplotlib.pyplot as plt
from ultralytics import YOLO
from pathlib import Path
import time
import warnings

# 忽略matplotlib字体警告
warnings.filterwarnings("ignore", category=UserWarning)

# 实验参数配置
class Config:
    # 模型配置：yolov5s为轻量级模型
    MODEL_PATH = "yolov5s.pt"
    # 输入图像路径
    IMG_INPUT_DIR = "campus_bike_images"
    # 输出结果路径
    IMG_OUTPUT_DIR = "bike_detection_results"
    # 共享单车类别ID：COCO数据集中"bicycle"类别ID为1（YOLOv5已预定义）
    BIKE_CLASS_ID = 1
    # 检测置信度阈值：过滤低置信度结果
    CONF_THRESHOLD = 0.3
    # 非极大值抑制阈值：去除重复检测框
    IOU_THRESHOLD = 0.45


# 创建输入/输出文件夹
Path(Config.IMG_INPUT_DIR).mkdir(exist_ok=True)
Path(Config.IMG_OUTPUT_DIR).mkdir(exist_ok=True)


# 设置中文字体
def set_chinese_font():
    try:
        # 尝试设置中文字体（Windows系统）
        plt.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei', 'DejaVu Sans']
        plt.rcParams['axes.unicode_minus'] = False
        # 尝试设置字体大小
        plt.rcParams['font.size'] = 10
    except:
        print("提示：中文字体设置失败，将使用默认字体")


# 调用字体设置函数
set_chinese_font()


# 图像预处理
def preprocess_campus_image(img_path):
    # 1. 读取图像
    img_bgr = cv2.imread(img_path)
    if img_bgr is None:
        raise FileNotFoundError(f"未找到图像文件：{img_path}，请检查路径是否正确")

    # 2. 转换为RGB格式
    img_rgb = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2RGB)

    # 3. 高斯滤波去噪
    img_blur = cv2.GaussianBlur(img_bgr, (5, 5), 0)

    # 4. 亮度调整
    # 转换为HSV空间（便于单独调整亮度）
    img_hsv = cv2.cvtColor(img_blur, cv2.COLOR_BGR2HSV)
    h, s, v = cv2.split(img_hsv)
    # 亮度增强
    v = np.clip(v * 1.2, 0, 255).astype(np.uint8)
    img_hsv_adjusted = cv2.merge((h, s, v))
    img_preprocessed = cv2.cvtColor(img_hsv_adjusted, cv2.COLOR_HSV2BGR)

    return img_preprocessed, img_rgb


# 共享单车检测（YOLOv5深度学习实现）
def load_yolo_model(model_path):
    """加载YOLOv5模型，支持预训练权重"""
    try:
        model = YOLO(model_path)
        print(f"✅ 成功加载YOLOv5模型：{model_path}")
        return model
    except Exception as e:
        raise RuntimeError(f"❌ 模型加载失败：{str(e)}，请检查模型路径或重新安装ultralytics库")


def detect_bicycles(model, img_preprocessed, conf_thresh, iou_thresh, bike_class_id):
    """
    执行共享单车检测
    :param model: YOLOv5模型
    :param img_preprocessed: 预处理后的BGR图像
    :param conf_thresh: 置信度阈值
    :param iou_thresh: IOU阈值
    :param bike_class_id: 共享单车类别ID
    :return: 检测结果（边界框、置信度）、带标注的图像
    """
    # 执行检测
    results = model(
        img_preprocessed,
        conf=conf_thresh,
        iou=iou_thresh,
        classes=[bike_class_id],
        verbose=False  # 关闭实时日志输出
    )

    # 解析检测结果
    bike_detections = []
    # 遍历检测结果
    for result in results:
        # 提取边界框（xyxy格式：左上x, 左上y, 右下x, 右下y）、置信度
        boxes = result.boxes.xyxy.numpy()  # 边界框坐标（像素）
        confs = result.boxes.conf.numpy()  # 置信度

        # 筛选共享单车检测结果
        for box, conf in zip(boxes, confs):
            x1, y1, x2, y2 = box
            bike_detections.append({
                "bbox": (int(x1), int(y1), int(x2), int(y2)),  # 转换为整数像素坐标
                "confidence": round(float(conf), 3)  # 保留3位小数
            })

    # 生成带标注的图像
    annotated_img_bgr = results[0].plot(
        conf=True,  # 显示置信度
        labels=True,  # 显示类别标签（"bicycle"）
        line_width=2,  # 标注框线宽
        font_size=10  # 字体大小
    )
    # 转换为RGB格式（用于Matplotlib显示）
    annotated_img_rgb = cv2.cvtColor(annotated_img_bgr, cv2.COLOR_BGR2RGB)

    return bike_detections, annotated_img_rgb, annotated_img_bgr


# 结果可视化与保存
def visualize_results(img_rgb, annotated_img_rgb, bike_detections, img_name):
    """
    对比显示原始图像与检测结果，生成可视化图表
    :param img_rgb: 原始RGB图像
    :param annotated_img_rgb: 带标注的RGB图像
    :param bike_detections: 检测结果列表
    :param img_name: 图像名称（用于保存）
    :return: 可视化图表路径
    """
    plt.figure(figsize=(16, 8))

    # 子图1：原始图像
    plt.subplot(1, 2, 1)
    plt.imshow(img_rgb)
    plt.title(f"Original Campus Image\nBicycles Detected: {len(bike_detections)}", fontsize=12)
    plt.axis("off")  # 隐藏坐标轴

    # 子图2：检测结果图像
    plt.subplot(1, 2, 2)
    plt.imshow(annotated_img_rgb)
    plt.title("Bicycle Detection Results (Green Boxes)", fontsize=12)
    plt.axis("off")

    # 调整子图间距，避免重叠
    plt.tight_layout()

    # 保存可视化结果
    vis_save_path = os.path.join(Config.IMG_OUTPUT_DIR, f"{img_name}_comparison.png")
    plt.savefig(vis_save_path, dpi=300, bbox_inches="tight")  # dpi=300确保高清
    plt.close()  # 关闭图表，释放内存

    return vis_save_path


def save_detection_results(annotated_img_bgr, bike_detections, img_name):
    """
    保存带标注的图像与检测日志
    :param annotated_img_bgr: 带标注的BGR图像
    :param bike_detections: 检测结果列表
    :param img_name: 图像名称
    :return: 标注图像路径、日志路径
    """
    # 1. 保存带标注的图像
    img_save_path = os.path.join(Config.IMG_OUTPUT_DIR, f"{img_name}_detected.jpg")
    cv2.imwrite(img_save_path, annotated_img_bgr)

    # 2. 保存检测日志
    log_save_path = os.path.join(Config.IMG_OUTPUT_DIR, f"{img_name}_detection_log.txt")
    with open(log_save_path, "w", encoding="utf-8") as f:
        f.write(f"校园共享单车检测日志\n")
        f.write(f"图像名称：{img_name}\n")
        f.write(f"检测时间：{time.strftime('%Y-%m-%d %H:%M:%S', time.localtime())}\n")
        f.write(f"检测到共享单车数量：{len(bike_detections)}\n")
        f.write("=" * 50 + "\n")
        for i, det in enumerate(bike_detections, 1):
            x1, y1, x2, y2 = det["bbox"]
            f.write(f"共享单车{i}：\n")
            f.write(f"  - 边界框坐标（左上x,左上y,右下x,右下y）：{x1}, {y1}, {x2}, {y2}\n")
            f.write(f"  - 置信度：{det['confidence']}\n")
            f.write(f"  - 检测区域面积（像素）：{(x2 - x1) * (y2 - y1)}\n")

    return img_save_path, log_save_path


# 批量检测
def batch_detect_bicycles():
    """批量处理文件夹中的校园图像，完成检测与结果保存"""
    # 1. 加载YOLOv5模型
    model = load_yolo_model(Config.MODEL_PATH)

    # 2. 遍历输入文件夹中的所有图像
    img_extensions = [".jpg", ".jpeg", ".png", ".bmp", ".tiff"]
    img_files = [f for f in os.listdir(Config.IMG_INPUT_DIR)
                 if os.path.splitext(f)[1].lower() in img_extensions]

    if not img_files:
        raise FileNotFoundError(f"在{Config.IMG_INPUT_DIR}文件夹中未找到图像文件，请检查输入路径或添加校园共享单车照片")

    # 3. 批量执行检测
    print(f"\n开始批量检测，共{len(img_files)}张图像...")
    for idx, img_file in enumerate(img_files, 1):
        img_name = os.path.splitext(img_file)[0]  # 图像名称（无后缀）
        img_path = os.path.join(Config.IMG_INPUT_DIR, img_file)
        print(f"\n正在处理第{idx}/{len(img_files)}张图像：{img_file}")

        try:
            # 步骤1：图像预处理
            img_preprocessed, img_rgb = preprocess_campus_image(img_path)

            # 步骤2：共享单车检测
            bike_detections, annotated_img_rgb, annotated_img_bgr = detect_bicycles(
                model=model,
                img_preprocessed=img_preprocessed,
                conf_thresh=Config.CONF_THRESHOLD,
                iou_thresh=Config.IOU_THRESHOLD,
                bike_class_id=Config.BIKE_CLASS_ID
            )

            # 步骤3：结果可视化与保存
            vis_path = visualize_results(img_rgb, annotated_img_rgb, bike_detections, img_name)
            img_save_path, log_save_path = save_detection_results(annotated_img_bgr, bike_detections, img_name)

            # 输出处理结果
            print(f"  ✅ 检测完成！")
            print(f"    - 检测到共享单车数量：{len(bike_detections)}")
            print(f"    - 可视化结果保存：{vis_path}")
            print(f"    - 标注图像保存：{img_save_path}")
            print(f"    - 检测日志保存：{log_save_path}")

        except Exception as e:
            print(f"  ❌ 处理失败：{str(e)}，跳过该图像")

    print(f"\n批量检测结束！所有结果已保存至：{os.path.abspath(Config.IMG_OUTPUT_DIR)}")


# 主函数
if __name__ == "__main__":
    # 执行批量检测（核心入口）
    batch_detect_bicycles()