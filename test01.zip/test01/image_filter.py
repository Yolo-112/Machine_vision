import numpy as np
import cv2
import matplotlib.pyplot as plt
import os

#  读取图像
def read_image(image_path):

    if not os.path.exists(image_path):
        raise FileNotFoundError(f"图像文件不存在: {image_path}")
    # 用cv2读取
    img = cv2.imread(image_path)
    img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    return img_rgb


# 自定义卷积滤波
def custom_convolution(img_gray, kernel):

    # 获取图像和核的尺寸
    img_h, img_w = img_gray.shape
    kernel_h, kernel_w = kernel.shape
    # 计算填充大小
    pad_h = kernel_h // 2
    pad_w = kernel_w // 2

    # 对图像进行零填充
    padded_img = np.zeros((img_h + 2 * pad_h, img_w + 2 * pad_w), dtype=np.float32)
    padded_img[pad_h:pad_h+img_h, pad_w:pad_w+img_w] = img_gray

    # 初始化输出图像
    filtered_img = np.zeros_like(img_gray, dtype=np.float32)

    # 逐像素卷积计算
    for i in range(img_h):
        for j in range(img_w):
            # 提取当前窗口区域
            window = padded_img[i:i+kernel_h, j:j+kernel_w]
            # 卷积运算（窗口与核逐元素相乘后求和）
            filtered_img[i, j] = np.sum(window * kernel)

    # 归一化到0-255
    filtered_img = np.clip(filtered_img, 0, 255).astype(np.uint8)
    return filtered_img


# Sobel算子滤波
def sobel_filter(img_gray):

    # Sobel x方向卷积核
    sobel_kernel = np.array([
        [-1, 0, 1],
        [-2, 0, 2],
        [-1, 0, 1]
    ], dtype=np.float32)
    # 调用自定义卷积函数
    sobel_img = custom_convolution(img_gray, sobel_kernel)
    return sobel_img


#  给定卷积核滤波
def given_kernel_filter(img_gray):
    # 实验指定的卷积核
    given_kernel = np.array([
        [1, 0, -1],
        [2, 0, -2],
        [1, 0, -1]
    ], dtype=np.float32)
    # 调用自定义卷积函数
    filtered_img = custom_convolution(img_gray, given_kernel)
    return filtered_img


# 手动计算颜色直方图
def compute_color_histogram(img_rgb):
    h, w, _ = img_rgb.shape
    # 初始化三通道直方图
    hist_r = np.zeros(256, dtype=int)
    hist_g = np.zeros(256, dtype=int)
    hist_b = np.zeros(256, dtype=int)

    # 逐像素统计每个通道的像素值出现次数
    for i in range(h):
        for j in range(w):
            r = img_rgb[i, j, 0]
            g = img_rgb[i, j, 1]
            b = img_rgb[i, j, 2]
            hist_r[r] += 1
            hist_g[g] += 1
            hist_b[b] += 1

    return hist_r, hist_g, hist_b


# 手动提取纹理特征（基于灰度共生矩阵GLCM)
def extract_texture_feature(img_gray):

    # 1. 灰度级压缩
    img_compressed = (img_gray // 16).astype(np.uint8)
    max_gray = 16  # 压缩后的最大灰度级

    # 2. 计算灰度共生矩阵
    glcm = np.zeros((max_gray, max_gray), dtype=int)
    h, w = img_compressed.shape
    for i in range(h):
        for j in range(w - 1):  # 避免列越界
            gray_i = img_compressed[i, j]
            gray_j = img_compressed[i, j+1]
            glcm[gray_i, gray_j] += 1

    # 3. 归一化GLCM
    glcm_prob = glcm / np.sum(glcm)

    # 4. 计算纹理特征
    contrast = 0.0  # 对比度
    energy = 0.0    # 能量
    entropy = 0.0   # 熵
    for i in range(max_gray):
        for j in range(max_gray):
            prob = glcm_prob[i, j]
            if prob == 0:
                continue
            contrast += (i - j) ** 2 * prob
            energy += prob ** 2
            entropy -= prob * np.log2(prob)

    # 整理特征
    texture_feature = {
        "contrast": contrast,
        "energy": energy,
        "entropy": entropy
    }
    return texture_feature


# 结果可视化与保存
def visualize_and_save_results(original_img, sobel_img, given_kernel_img, hist_r, hist_g, hist_b, texture_feature):
    # 创建保存目录
    save_dir = "experiment_results"
    os.makedirs(save_dir, exist_ok=True)

    # 1. 可视化原始图像、Sobel滤波、给定核滤波结果
    plt.figure(figsize=(15, 5))
    plt.subplot(1, 3, 1)
    plt.imshow(original_img)
    plt.title("Original Image")
    plt.axis("off")

    plt.subplot(1, 3, 2)
    plt.imshow(sobel_img, cmap="gray")
    plt.title("Sobel Filtered Image")
    plt.axis("off")

    plt.subplot(1, 3, 3)
    plt.imshow(given_kernel_img, cmap="gray")
    plt.title("Given Kernel Filtered Image")
    plt.axis("off")

    # 保存滤波结果图
    filter_save_path = os.path.join(save_dir, "filter_results.png")
    plt.savefig(filter_save_path, bbox_inches="tight")
    plt.close()

    # 2. 可视化颜色直方图
    plt.figure(figsize=(12, 4))
    plt.subplot(1, 3, 1)
    plt.bar(range(256), hist_r, color="red", alpha=0.7)
    plt.title("Red Channel Histogram")
    plt.xlabel("Pixel Value")
    plt.ylabel("Count")

    plt.subplot(1, 3, 2)
    plt.bar(range(256), hist_g, color="green", alpha=0.7)
    plt.title("Green Channel Histogram")
    plt.xlabel("Pixel Value")
    plt.ylabel("Count")

    plt.subplot(1, 3, 3)
    plt.bar(range(256), hist_b, color="blue", alpha=0.7)
    plt.title("Blue Channel Histogram")
    plt.xlabel("Pixel Value")
    plt.ylabel("Count")

    # 保存直方图
    hist_save_path = os.path.join(save_dir, "color_histogram.png")
    plt.savefig(hist_save_path, bbox_inches="tight")
    plt.close()

    # 3. 保存纹理特征到npy文件
    texture_save_path = os.path.join(save_dir, "texture_feature.npy")
    np.save(texture_save_path, texture_feature)
    print(f"纹理特征已保存至: {texture_save_path}")


# 主程序
if __name__ == "__main__":

    IMAGE_PATH = "campus_road.jpg"

    try:
        # 步骤1：读取图像
        original_img = read_image(IMAGE_PATH)
        # 转为灰度图（用于滤波和纹理特征）
        img_gray = cv2.cvtColor(cv2.imread(IMAGE_PATH), cv2.COLOR_BGR2GRAY)

        # 步骤2：Sobel算子滤波
        sobel_img = sobel_filter(img_gray)

        # 步骤3：给定卷积核滤波
        given_kernel_img = given_kernel_filter(img_gray)

        # 步骤4：计算颜色直方图
        hist_r, hist_g, hist_b = compute_color_histogram(original_img)

        # 步骤5：提取纹理特征
        texture_feature = extract_texture_feature(img_gray)
        print("提取的纹理特征：")
        print(f"  对比度(Contrast): {texture_feature['contrast']:.4f}")
        print(f"  能量(Energy): {texture_feature['energy']:.4f}")
        print(f"  熵(Entropy): {texture_feature['entropy']:.4f}")

        # 步骤6：可视化并保存所有结果
        visualize_and_save_results(
            original_img, sobel_img, given_kernel_img,
            hist_r, hist_g, hist_b, texture_feature
        )
        print(f"\n所有实验结果已保存至: {os.path.abspath('experiment_results')}")

    except Exception as e:
        print(f"程序运行出错: {str(e)}")