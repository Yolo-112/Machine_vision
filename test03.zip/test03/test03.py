import cv2
import numpy as np
import matplotlib.pyplot as plt
from tensorflow.keras.datasets import mnist
from tensorflow.keras.utils import to_categorical
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Input, Conv2D, MaxPooling2D, Flatten, Dense, Dropout
from tensorflow.keras.optimizers import Adam


# 数据预处理
def preprocess_mnist_data():
    """加载并预处理MNIST训练集/测试集"""
    # 加载MNIST数据集
    (x_train, y_train), (x_test, y_test) = mnist.load_data()

    # 维度调整：[样本数, 28, 28] → [样本数, 28, 28, 1]
    x_train = x_train.reshape(-1, 28, 28, 1).astype("float32") / 255.0
    x_test = x_test.reshape(-1, 28, 28, 1).astype("float32") / 255.0

    # 标签独热编码（10个数字类别）
    y_train = to_categorical(y_train, 10)
    y_test = to_categorical(y_test, 10)

    return (x_train, y_train), (x_test, y_test)


def preprocess_id_photo(photo_path):
    #预处理学号照片
    # 读取照片
    img = cv2.imread(photo_path)
    if img is None:
        raise FileNotFoundError(f"未找到学号照片，路径：{photo_path}")

    # 1. 灰度化+二值化
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    # 自适应二值化（自动调整阈值，抗光照干扰）
    _, binary = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)

    # 2. 形态学操作
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (2, 2))
    binary = cv2.morphologyEx(binary, cv2.MORPH_CLOSE, kernel)  # 闭运算：先膨胀后腐蚀
    binary = cv2.morphologyEx(binary, cv2.MORPH_OPEN, kernel)  # 开运算：先腐蚀后膨胀

    # 3. 查找数字轮廓
    contours, _ = cv2.findContours(binary, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    digit_rois = []  # 存储每个数字的预处理结果
    bounding_boxes = []  # 存储数字在原图中的位置（用于可视化）

    for cnt in contours:
        # 过滤过小轮廓
        if cv2.contourArea(cnt) < 80:
            continue

        # 获取轮廓边界框
        x, y, w, h = cv2.boundingRect(cnt)
        bounding_boxes.append((x, y, w, h))

        # 4. 提取ROI并补全为正方形
        roi = binary[y:y + h, x:x + w]
        side_len = max(w, h)  # 取宽高最大值作为正方形边长
        # 边界填充
        roi_padded = cv2.copyMakeBorder(
            roi,
            top=(side_len - h) // 2,
            bottom=(side_len - h + 1) // 2,
            left=(side_len - w) // 2,
            right=(side_len - w + 1) // 2,
            borderType=cv2.BORDER_CONSTANT,
            value=0
        )

        # 5. 调整为28×28+ 归一化
        roi_resized = cv2.resize(roi_padded, (28, 28), interpolation=cv2.INTER_AREA)
        roi_normalized = roi_resized.astype("float32") / 255.0
        # 增加维度：[28,28] → [1,28,28,1]
        roi_input = np.expand_dims(np.expand_dims(roi_normalized, axis=-1), axis=0)
        digit_rois.append(roi_input)

    # 按x坐标排序
    if digit_rois and bounding_boxes:
        sorted_indices = sorted(range(len(bounding_boxes)), key=lambda i: bounding_boxes[i][0])
        digit_rois = [digit_rois[i] for i in sorted_indices]
        bounding_boxes = [bounding_boxes[i] for i in sorted_indices]

    if not digit_rois:
        raise ValueError("未从照片中提取到有效数字，请确保照片背景干净、数字清晰")

    return digit_rois, bounding_boxes, img


#  搭建CNN模型
def build_cnn_model():
    model = Sequential([
        Input(shape=(28, 28, 1)),  # 输入层：28×28灰度图

        # 第1卷积块：卷积+池化
        Conv2D(filters=32, kernel_size=(3, 3), activation="relu", padding="same", name="conv1"),
        MaxPooling2D(pool_size=(2, 2), strides=2, name="pool1"),

        # 第2卷积块：卷积+池化
        Conv2D(filters=64, kernel_size=(3, 3), activation="relu", padding="same", name="conv2"),
        MaxPooling2D(pool_size=(2, 2), strides=2, name="pool2"),

        # 第3卷积块
        Conv2D(filters=128, kernel_size=(3, 3), activation="relu", padding="same", name="conv3"),
        MaxPooling2D(pool_size=(2, 2), strides=2, name="pool3"),

        # 分类头：全连接层+Dropout
        Flatten(name="flatten"),  # 展平：[3,3,128] → 1152维向量
        Dense(units=256, activation="relu", name="dense1"),  # 全连接层：256个神经元
        Dropout(rate=0.3, name="dropout1"),  # 随机丢弃30%神经元，抑制过拟合
        Dense(units=128, activation="relu", name="dense2"),
        Dropout(rate=0.2, name="dropout2"),
        Dense(units=10, activation="softmax", name="output")  # 输出层：10个数字概率
    ])

    # 编译模型
    model.compile(
        optimizer=Adam(learning_rate=0.001),
        loss="categorical_crossentropy",  # 多分类任务损失函数
        metrics=["accuracy"]  # 评价指标：准确率
    )

    return model


# 模型训练与保存
def train_model(model, x_train, y_train, x_test, y_test, epochs=8, batch_size=32):
    print("开始训练模型...")
    history = model.fit(
        x_train, y_train,
        batch_size=batch_size,
        epochs=epochs,
        validation_data=(x_test, y_test),
        verbose=1  # 显示训练进度
    )

    # 保存训练好的模型
    model.save("mnist_cnn_id_recognition.h5")
    print("模型保存成功：mnist_cnn_id_recognition.h5")

    return history


# 学号识别与结果可视化
def recognize_id(model, digit_rois, bounding_boxes, original_img):
    id_digits = []  # 存储识别出的学号数字
    img_with_annotation = original_img.copy()  # 用于绘制标注的图像

    for i, (roi, (x, y, w, h)) in enumerate(zip(digit_rois, bounding_boxes)):
        # 预测数字
        pred_prob = model.predict(roi, verbose=0)
        pred_digit = np.argmax(pred_prob)  # 取概率最大的数字
        id_digits.append(str(pred_digit))

        # 在原图上绘制标注
        cv2.rectangle(img_with_annotation, (x, y), (x + w, y + h), (0, 255, 0), 2)
        cv2.putText(
            img_with_annotation,
            str(pred_digit),
            (x, y - 10),  # 标签位置（矩形框上方）
            cv2.FONT_HERSHEY_SIMPLEX,
            1,  # 字体大小
            (255, 0, 0),  # 字体颜色（蓝色）
            2  # 字体粗细
        )

    # 拼接学号
    recognized_id = "".join(id_digits)
    # 在图像顶部添加完整学号
    cv2.putText(
        img_with_annotation,
        f"Recognized ID: {recognized_id}",
        (20, 40),
        cv2.FONT_HERSHEY_SIMPLEX,
        1.2,
        (0, 0, 255),
        3
    )

    return recognized_id, img_with_annotation


# 训练过程与结果可视化
def plot_training_history(history):
    """绘制训练过程的准确率和损失曲线"""
    plt.figure(figsize=(12, 4))

    # 准确率曲线
    plt.subplot(1, 2, 1)
    plt.plot(history.history["accuracy"], label="Train Accuracy", color="blue")
    plt.plot(history.history["val_accuracy"], label="Test Accuracy", color="orange")
    plt.xlabel("Epoch")
    plt.ylabel("Accuracy")
    plt.title("Model Accuracy")
    plt.legend()
    plt.grid(True, alpha=0.3)

    # 损失曲线
    plt.subplot(1, 2, 2)
    plt.plot(history.history["loss"], label="Train Loss", color="blue")
    plt.plot(history.history["val_loss"], label="Test Loss", color="orange")
    plt.xlabel("Epoch")
    plt.ylabel("Loss")
    plt.title("Model Loss")
    plt.legend()
    plt.grid(True, alpha=0.3)

    plt.tight_layout()
    plt.savefig("training_history.png", dpi=300, bbox_inches="tight")
    plt.show()


def plot_recognition_result(original_img, result_img):
    #对比显示原始照片和识别结果
    plt.figure(figsize=(15, 6))

    # 原始照片
    plt.subplot(1, 2, 1)
    plt.imshow(cv2.cvtColor(original_img, cv2.COLOR_BGR2RGB))
    plt.title("Original ID Photo")
    plt.axis("off")

    # 识别结果
    plt.subplot(1, 2, 2)
    plt.imshow(cv2.cvtColor(result_img, cv2.COLOR_BGR2RGB))
    plt.title("ID Recognition Result")
    plt.axis("off")

    plt.tight_layout()
    plt.savefig("id_recognition_result.png", dpi=300, bbox_inches="tight")
    plt.show()


# 主函数
if __name__ == "__main__":
    # 配置参数
    ID_PHOTO_PATH = "my_student_id.jpg"

    try:
        # 步骤1：预处理MNIST数据
        (x_train, y_train), (x_test, y_test) = preprocess_mnist_data()
        print(f"MNIST数据加载完成：训练集{len(x_train)}样本，测试集{len(x_test)}样本")

        # 步骤2：搭建模型
        model = build_cnn_model()
        model.summary()  # 打印模型结构

        # 步骤3：训练模型
        history = train_model(model, x_train, y_train, x_test, y_test, epochs=8, batch_size=32)
        plot_training_history(history)  # 可视化训练过程

        # 步骤4：加载已训练模型
        # from tensorflow.keras.models import load_model
        # model = load_model("mnist_cnn_id_recognition.h5")
        # print("已加载预训练模型")

        # 步骤5：预处理学号照片
        digit_rois, bounding_boxes, original_img = preprocess_id_photo(ID_PHOTO_PATH)
        print(f"成功提取到{len(digit_rois)}个数字区域")

        # 步骤6：识别学号
        recognized_id, result_img = recognize_id(model, digit_rois, bounding_boxes, original_img)

        # 步骤7：显示并保存结果
        plot_recognition_result(original_img, result_img)
        print(f"\n✅ 学号识别结果：{recognized_id}")

        # 保存识别结果图像
        cv2.imwrite("final_id_recognition_result.jpg", result_img)
        print("识别结果图像已保存：final_id_recognition_result.jpg")

    except Exception as e:
        print(f"\n❌ 程序运行出错：{str(e)}")