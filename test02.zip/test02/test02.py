import cv2
import numpy as np
import matplotlib.pyplot as plt


def lane_detection(img_path):
    # 1. 读取图像
    img = cv2.imread(img_path)
    img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    height, width = img.shape[:2]

    # 2. 预处理：灰度化+高斯滤波+边缘检测
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    blur = cv2.GaussianBlur(gray, (5, 5), 0)
    edges = cv2.Canny(blur, 50, 150)

    # 3. 感兴趣区域提取（只保留道路区域）
    mask = np.zeros_like(edges)
    roi_vertices = np.array([[(0, height), (width / 2, height / 2), (width, height)]], dtype=np.int32)
    cv2.fillPoly(mask, roi_vertices, 255)
    masked_edges = cv2.bitwise_and(edges, mask)

    # 4. 霍夫变换检测直线
    lines = cv2.HoughLinesP(
        masked_edges,
        rho=1,
        theta=np.pi / 180,
        threshold=50,
        minLineLength=50,
        maxLineGap=100
    )

    # 5. 绘制车道线
    lane_img = np.zeros_like(img)
    if lines is not None:
        for line in lines:
            x1, y1, x2, y2 = line[0]
            cv2.line(lane_img, (x1, y1), (x2, y2), (0, 255, 0), 5)

    # 6. 合并结果
    result = cv2.addWeighted(img, 0.8, lane_img, 1, 0)
    return img_rgb, masked_edges, cv2.cvtColor(result, cv2.COLOR_BGR2RGB)


# 运行检测
img_path = "campus_lane.jpg"
original, edges, result = lane_detection(img_path)

# 显示结果
plt.figure(figsize=(15, 5))

plt.subplot(1, 3, 1), plt.imshow(original), plt.title("Original Image")
plt.subplot(1, 3, 2), plt.imshow(edges, cmap="gray"), plt.title("Edge Detection Result")
plt.subplot(1, 3, 3), plt.imshow(result), plt.title("Lane Detection Result")
plt.tight_layout()
plt.savefig("lane_detection_result.png")
plt.show()

# 保存最终结果
cv2.imwrite("lane_detection_final.jpg", cv2.cvtColor(result, cv2.COLOR_RGB2BGR))